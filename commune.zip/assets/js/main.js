$(document).on('change', '.file-input', function(){
 $(this).next().next('span').html(this.files[0].name);
})

document.addEventListener('DOMContentLoaded', function () {

  // Get all "navbar-burger" elements
  var $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);

  // Check if there are any navbar burgers
  if ($navbarBurgers.length > 0) {

    // Add a click event on each of them
    $navbarBurgers.forEach(function ($el) {
      $el.addEventListener('click', function () {

        // Get the target from the "data-target" attribute
        var target = $el.dataset.target;
        var $target = document.getElementById(target);

        // Toggle the class on both the "navbar-burger" and the "navbar-menu"
        $el.classList.toggle('is-active');
        $target.classList.toggle('is-active');

      });
    });
  }
});

// var modalButtons = document.querySelectorAll('.modal-button');
var closeModal = document.querySelectorAll('.modal-close, .modal-background');
// if(modalButtons != null){
//   for(i = 0; i < modalButtons.length; i++){
//     modalButtons[i].addEventListener('click', function(){
//       
//     })
//   }
// }

$('.editRecord').on('click', '.modal-close, .modal-background', function(){
  $(this).parent().fadeOut(500, function(){
    $(this).parent().removeClass('is-active');
  });
  $(this).parent().html('');
})

$('.editRecord').on('click', '[aria-label="close"]', function(e){
  e.preventDefault();
})

$('.modal-button').click(function(){
  var $target = this.dataset.target;
  var target = document.getElementById($target);
  target.classList.add('is-active');
  $(target).hide();
  $(target).fadeIn(300);
})

$('#dataTable').on('click', '.modal-button', function(){
  var $target = this.dataset.target;
  var target = document.getElementById($target);
  target.classList.add('is-active');
  $(target).hide();
  $(target).fadeIn(300);
})

$('[aria-label="close"]').click(function(e){
  e.preventDefault();
})

if(closeModal != null){
  for(i = 0; i < closeModal.length; i++){
    closeModal[i].addEventListener('click', function(){
      $(this.parentNode).fadeOut(200, function(){
        this.parentNode.classList.remove('is-active');
      });
    })
  }
}

$(document).ready(function(){
  if($(window).scrollTop() > 51 && $('#navbar').hasClass('is-spaced')){
    $('#navbar').removeClass('is-spaced');
  }else if($(window).scrollTop() > 51){
    $('#navbar').removeClass('is-spaced');
  }else{
    $('#navbar').addClass('is-spaced');
  }
  $(window).scroll(function(){
    if($(window).scrollTop() > 51 && $('#navbar').hasClass('is-spaced')){
      $('#navbar').removeClass('is-spaced');
    }else if($(window).scrollTop() > 51){
      $('#navbar').removeClass('is-spaced');
    }else{
      $('#navbar').addClass('is-spaced');
    }
  });
})

$(document).ready(function(){
  var backTop = $('#scroll-top');
  backTop.click(function(e){
    $('html').animate({scrollTop:0}, 'slow');
    return false;
  })
})

$(document).ready(function(){
  var $currentIndex = 0,
      $slideShow = $('#caroussel'),
      $actu = $('.slideShow'),
      $indexActu = $actu.length - 1,
      $i = 0,
      $currentActu = $actu.eq($i);
      $actu.hide();
      $currentActu.fadeIn(200);
      $('#next').click(function(){ // image suivante

          $i++; // on incrémente le compteur
          if($i > $indexActu){
            $i = 0;
          }  
          $actu.hide(); // on cache les images
          $currentActu.fadeIn(200); // puis on l'affiche
          $currentActu = $actu.eq($i); // on définit la nouvelle image   
          console.log($i);       
      });

      $('#prev').click(function(){ // image précédente

          $i--; // on décrémente le compteur, puis on réalise la même chose que pour la fonction "suivante"
            console.log($i);
          if($i >= 0){
            $actu.hide();
            $currentActu = $actu.eq($i);
            $currentActu.fadeIn(200);
          }else{
            $i = $indexActu;
          }    
      });

      function slide(){
        setTimeout(function(){
          $i++; // on incrémente le compteur
          if($i > $indexActu){
            $i = 0;
          }  
          $actu.hide(); // on cache les images
          $currentActu.fadeIn(200); // puis on l'affiche
          $currentActu = $actu.eq($i); // on définit la nouvelle image   
          console.log($i); 
          slide();
        }, 2000);
      }

})

