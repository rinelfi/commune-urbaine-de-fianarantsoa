<div class="container block">
<div class="columns">
        <!-- Aside nav drawer -->
        <div class="column">
            <div class="box">
                <h1 class="title is-2" style="font-weight: 600;">
                    <?php 
                        $content = array();
                        foreach($article as $valeur){
                            $content = $valeur;
                            echo $content->titre;
                        }
                    ?>  
                </h1>
                <div class="content">
                    <img src="<?php echo base_url('assets/img/article/couverture/'.$content->image)?>" style="width: 100%; max-width: 400px; float: left; margin: 0 20px 20px 0;">
                    <div style="text-align: justify;">
                        <?php 
                        echo $content->contenu;
                        ?>
                    <p class="has-text-right"><i><strong><?php echo $content->nom.' '.$content->prenom;?></strong></i></p>
                    </div>
                </div>
            </div>
            <div class="block box">
                <p class="subtitle inherit is-2">Commentaire</p>
                <article class="media box block">
                  <div class="media-content">
                    <div class="content">
                      <p>
                        <span class="subtitle is-3">John Smith</span> <small>@johnsmith</small> <small>31m</small>
                        <br>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin ornare magna eros, eu pellentesque tortor vestibulum ut. Maecenas non massa sem. Etiam finibus odio quis feugiat facilisis.
                      </p>
                    </div>
                  </div>
                </article>
                <div>
                    <p class="subtitle is-4">Laisser un commentaire :</p>
                    <form>
                        <div class="field">
                          <p class="control">
                            <textarea class="textarea" placeholder="Add a comment..."></textarea>
                          </p>
                        </div>
                        <nav class="level">
                          <div class="level-left">
                            <div class="level-item">
                              <a class="button is-info">Submit</a>
                            </div>
                          </div>
                          <div class="level-right">
                            <div class="level-item">
                              <label class="checkbox">
                                <input type="checkbox"> Press enter to submit
                              </label>
                            </div>
                          </div>
                    </form>
                </div>
            </div>
        </div>