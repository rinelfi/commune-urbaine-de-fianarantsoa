<div class="container block"> 
    <div class="columns">
        <!-- Aside nav drawer -->
        <div class="column">
            <div class="box content">
            <?php
                $recent;
                foreach($menuParent as $valeur){
                    if($this->uri->segment(2) == $valeur->reference){
                        $recent = $valeur;
                        if($this->uri->segment(1) != '' && $this->uri->segment(3) != ''){
                            $recent = $this->Menu->menuGetInfo($this->uri->segment(3));
                            $recent = $recent[0];
                        }
                    }
                }
                if($recent->type_contenu == 'text'){
                    echo $recent->contenu;
                    echo 'Salut';
                }
            ?>
        </div>
    </div>