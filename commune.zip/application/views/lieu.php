<div class="container">
<div class="columns">
        <!-- Aside nav drawer -->
        <div class="column">
            <p class="title">Sites remarquables:</p>
            <div class="columns is-multiline box">
                <?php
                    $recent;
                    for($i = 0; $i < 10; $i++){
                        ?>
                            <div class="column is-4">
                                <div class="card" style="transition: all .1s ease;">
                                  <div class="card-image">
                                    <figure class="image is-5by3">
                                      <img src="<?php echo img_url('betsileo');?>">
                                    </figure>
                                  </div>
                                  <div class="card-content">
                                    <div class="content">
                                        Fianarantsoa
                                    </div>
                                  </div>
                                </div>
                            </div>
                        <?php
                    }
                ?>
            </div>
        </div>