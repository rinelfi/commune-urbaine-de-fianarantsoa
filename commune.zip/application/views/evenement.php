<div class="container block">
<div class="columns">
        <!-- Aside nav drawer -->
        <div class="column">
            <p class="title">Evenements:</p>
            <div class="columns is-multiline">
              <?php for($i = 0; $i < 10; $i++){ ?>
                <div class="column is-4">
                  <div class="box event">
                    <article class="media">
                      <div class="media-left">
                        <figure class="image is-64x64">
                          <img src="<?php echo img_url('fest', 'png') ?>" alt="Image">
                        </figure>
                      </div>
                      <div class="media-content">
                        <div class="content">
                          <p>
                            <strong>Fête national</strong>
                            <br>
                            Fête national le 13 Mai 2018 à Fianarantsoa
                          </p>
                        </div>
                        <nav class="level is-mobile">
                          <div class="level-left">
                            <a class="level-item">
                              <span class="icon is-small"><i class="fa fa-reply"></i></span>
                            </a>
                            <a class="level-item">
                              <span class="icon is-small"><i class="fa fa-retweet"></i></span>
                            </a>
                            <a class="level-item">
                              <span class="icon is-small"><i class="fa fa-heart"></i></span>
                            </a>
                          </div>
                        </nav>
                      </div>
                    </article>
                  </div>
                </div>
              <?php } ?>
            </div>
        </div>