
          <div class="box">
            <div class="field is-grouped">
              <p class="control">
                <button class="button modal-button" data-target="modal">Nouveau document</button>
              </p>
              <p class="control">
                <button class="button modal-button" data-target="modal">Nouveau type de document</button>
              </p>
            </div>
            <div id="modal" class="modal text">
              <div class="modal-background"></div>
              <div class="modal-card" width="1000">
                <header class="modal-card-head">
                  <p class="modal-card-title">Menu parent</p>
                </header>
                <section class="modal-card-body">
                  <form>
                    <div class="field">
                      <label class="label">Nom</label>
                      <p class="control has-icons-left">
                        <input class="input" type="text" name="nom" id="nom" placeholder="ex: Home">
                        <span class="icon is-small is-left">
                          <i class="fa fa-sitemap"></i>
                        </span>
                      </p>
                    </div>
                    <div class="field">
                      <label class="label">Référence</label>
                      <p class="control has-icons-left">
                        <input class="input" type="text" name="reference" id="reference" placeholder="ex: home/">
                        <span class="icon is-small is-left">
                          <i class="fa fa-anchor"></i>
                        </span>
                      </p>
                    </div>
                    <div class="field">
                      <label class="label">Type de menu</label>
                      <div class="control has-icons-left is-expanded">
                        <div class="select is-expanded">
                          <select>
                            <option value=''>Défaut</option>
                            <option>Personnalisé</option>
                          </select>
                        </div>
                        <div class="icon is-small is-left">
                          <i class="fa fa-globe"></i>
                        </div>
                      </div>
                    </div>
                    <div class="field">
                      <label class="label">Description du Menu</label>
                      <div class="control">
                          <textarea class="textarea" name="description" placeholder="Description du menu pour une réferencement au moteur de recherche"></textarea>
                      </div>
                    </div>
                  </form>
                </section>
                <footer class="modal-card-foot">
                  <button class="button is-success">Enregistrer</button>
                  <button class="button">Annuler</button>
                </footer>
              </div>
              <button class="modal-close is-large" aria-label="close"></button>
            </div>
              <table class="table is-narrow is-fullwidth">
                <thead>
                  <tr>
                    <th><abbr title="Nom avec le type de document">Titre</abbr></th>
                    <th class="has-text-centered">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th class="has-text-centered">20</th>
                    <td class="has-text-centered is-narrow"><button class="button">Supprimer</button></td>
                  </tr>
                </tbody>
              </table>
              <nav class="pagination" role="navigation" aria-label="pagination">
                <a class="pagination-previous" title="This is the first page" disabled>Previous</a>
                <a class="pagination-next">Next page</a>
                <ul class="pagination-list">
                  <li>
                    <a class="pagination-link is-current" aria-label="Page 1" aria-current="page">1</a>
                  </li>
                  <li>
                    <a class="pagination-link" aria-label="Goto page 2">2</a>
                  </li>
                  <li>
                    <a class="pagination-link" aria-label="Goto page 3">3</a>
                  </li>
                </ul>
              </nav>
          </div>
      </div>
    </div>
</body>

</html>
