    <script type="text/javascript" src="<?php echo js_url('jquery-confirm.min');?>"></script>
    <script type="text/javascript" src="<?php echo js_url('main');?>"></script>
    <script type="text/javascript" src="<?php echo js_url('ckeditor');?>"></script>
    