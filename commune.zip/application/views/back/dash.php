
          <section class="hero is-primary welcome is-small admin-bottom">
            <div class="hero-body">
              <div class="container">
                <p class="title is-1 inherit">Tableau de bord</p>
              </div>
            </div>
          </section>
          <div class="columns is-multiline">
            <div class="column">
              <div class="box notification is-info">
                <div class="heading">Documents téléchargeables</div>
                <div class="title">50</div>
                <div class="level">
                  <div class="level-item">
                    <div class="">
                      <div class="heading">Téléchargement</div>
                      <div class="title is-5">1560</div>
                    </div>
                  </div>
                  <div class="level-item">
                    <div class="">
                      <div class="heading">Neg</div>
                      <div class="title is-5">368</div>
                    </div>
                  </div>
                  <div class="level-item">
                    <div class="">
                      <div class="heading">Pos/Neg %</div>
                      <div class="title is-5">77% / 23%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="column">
              <div class="box notification is-info">
                <div class="heading">Feedback Activity</div>
                <div class="title">78% ↑</div>
                <div class="level">
                  <div class="level-item">
                    <div class="">
                      <div class="heading">Pos</div>
                      <div class="title is-5">1560</div>
                    </div>
                  </div>
                  <div class="level-item">
                    <div class="">
                      <div class="heading">Neg</div>
                      <div class="title is-5">368</div>
                    </div>
                  </div>
                  <div class="level-item">
                    <div class="">
                      <div class="heading">Pos/Neg %</div>
                      <div class="title is-5">77% / 23%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-6">
            <div class="panel">
              <p class="panel-heading">
                Affluence de visiteurs
              </p>
              <div class="panel-block">
                <div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;" class="chartjs-size-monitor">
                  <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                    <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                  </div>
                  <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                    <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                  </div>
                </div>
                <div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;" class="chartjs-size-monitor">
                  <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                    <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                  </div>
                  <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                    <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                  </div>
                </div>
                <canvas id="chartDoughnut" width="518" height="518" style="display: block; width: 518px; height: 518px;" class="chartjs-render-monitor"></canvas>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
</body>

</html>
