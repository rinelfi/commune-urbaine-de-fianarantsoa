
          <div class="box">
              <table class="table is-narrow is-fullwidth is-hoverable">
                <tbody>
                  <tr>
                    <td id="personne" class="is-narrow">RIJANIAINA Elie Fidèle</td>
                    <td style="text-overflow: ellipsis; word-wrap: unset;"><strong>Administrateur</strong> - Tralala tralala tralala tralala tralala tralala tralala tralala tralala tralala tralala tralala tralala tralala tralala</td>
                    <td class="has-text-centered is-narrow">
                      <div class="field is-grouped">
                        <p class="control">
                          <button class="button">Détail</button>
                        </p>
                        <p class="control">
                          <button class="button">Supprimer</button>
                        </p>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
              <nav class="pagination" role="navigation" aria-label="pagination">
                <a class="pagination-previous" title="This is the first page" disabled>Previous</a>
                <a class="pagination-next">Next page</a>
                <ul class="pagination-list">
                  <li>
                    <a class="pagination-link is-current" aria-label="Page 1" aria-current="page">1</a>
                  </li>
                  <li>
                    <a class="pagination-link" aria-label="Goto page 2">2</a>
                  </li>
                  <li>
                    <a class="pagination-link" aria-label="Goto page 3">3</a>
                  </li>
                </ul>
              </nav>
          </div>
      </div>
    </div>
</body>

</html>
