
          <div class="box">
            <button class="button block modal-button is-success addRec" id="addRecord" data-target="modal">
              <span class="icon">
                <i class="fa fa-plus"></i>
              </span>
              <span>Nouveau Menu</span>
            </button>


            <form action="" method="POST">
            <div id="modal" class="modal big-modal">
              <div class="modal-background"></div>
              <div class="modal-card">
                <header class="modal-card-head">
                  <p class="modal-card-title">Menu parent</p>
                </header>
                <section class="modal-card-body">
                    <div class="field">
                      <label class="label">Nom</label>
                      <p class="control has-icons-left">
                        <input class="input" type="text" name="addNom" id="addNom" placeholder="ex: Home">
                        <span class="icon is-small is-left">
                          <i class="fa fa-sitemap"></i>
                        </span>
                      </p>
                      <p class="help is-danger" style="display: none;">Ce champ est requis</p>
                    </div>
                    <div class="field">
                      <label class="label">Référence</label>
                      <p class="control has-icons-left">
                        <input class="input" type="text" name="addReference" id="addReference" placeholder="ex: home/">
                        <span class="icon is-small is-left">
                          <i class="fa fa-anchor"></i>
                        </span>
                      </p>
                      <p class="help is-danger" style="display: none;">Le menu a besoin de réference</p>
                    </div>
                    <div class="field">
                      <label class="label">Type de menu</label>
                      <div class="control has-icons-left is-expanded">
                        <div class="select is-expanded">
                          <select id="addType" name="addType">
                            <option value='text'>Text</option>
                            <option value='custom'>Custom</option>
                          </select>
                        </div>
                        <div class="icon is-small is-left">
                          <i class="fa fa-globe"></i>
                        </div>
                      </div>
                    </div>
                    <div class="field">
                      <label class="label">Contenu du menu (si le type est "Text")</label>
                      <div class="control">
                          <textarea class="textarea ckeditor" name="addContenu" id="addContenu"></textarea>
                      </div>
                    </div>
                    <div class="field">
                      <label class="label">Description du Menu</label>
                      <div class="control">
                          <textarea class="textarea" name="addDescription" id="addDescription" placeholder="Description du menu pour une réferencement au moteur de recherche"></textarea>
                      </div>
                      <p class="help is-danger" style="display: none;">La déscription est essentiel au référencement</p>
                    </div>
                </section>
                <footer class="modal-card-foot">
                  <button class="button is-success" id="save" name="save">Enregistrer</button>
                  <input type="button" class="button is-danger" id="reset" value="Annuler">
                </footer>
              </div>
              <button class="modal-close is-large" aria-label="close"></button>
            </div>
          </form>

          <form action="" method="POST">
            <div id="modalEdit" class="modal big-modal editRecord">
              
            </div>
          </form>


              <table class="table is-narrow is-fullwidth">
                <thead>
                  <tr>
                    <th><abbr title="Titre du menu">Titre</abbr></th>
                    <th><abbr title="Lien où le menu fait réference">Réference</abbr></th>
                    <th><abbr title="le contenu est 'Défaut' si le contenu est saisi directement avec le menu, mais personnalisé si le contenu se trouve dans un autre table">Type</abbr></th>
                    <th class="is-narrow">Action</th>
                  </tr>
                </thead>
                <tbody id="dataTable">

                </tbody>
              </table>
          </div>
      </div>
    </div>
    <script type="text/javascript">
      $('#addRecord').click(function(){
        $('form').attr('action', '<?php echo base_url('back/menu_parent/addRecord');?>')
      })

      /*
      *
      *
      *
      *sauvegarde et contrôle champ
      *
      *
      *
      */

      $('#save').click(function(e){
        e.preventDefault();
        var valide = true;
        var link = '<?php echo base_url('back/menu_parent/addRecord');?>',
            nom = $('#addNom').val(),
            reference = $('#addReference').val(),
            type = $('#addType').val(),
            description = $('#addDescription').val(),
            contenu = CKEDITOR.instances['addContenu'].getData();
            sending = {
              'addNom': nom,
              'addReference': reference,
              'addType': type,
              'addContenu': contenu,
              'addDescription': description
            };
        if(nom == '' || reference == '' || description == ''){
            if(nom == ''){
              $('#addNom').addClass('is-danger');
              $('#addNom').parent().next('p').fadeIn(200);
            }
            if(reference == ''){
              $('#addReference').addClass('is-danger');
              $('#addReference').parent().next('p').fadeIn(200);
            }
            if(description == ''){
              $('#addDescription').addClass('is-danger');
              $('#addDescription').parent().next('p').fadeIn(200);
            }
            valide = false;
          }else{
            valide = true;
          }

          if($('#addNom').hasClass('is-danger') && nom != ''){
            $('#addNom').removeClass('is-danger');
            $('#addNom').parent().next('p').fadeOut(200);
          }
          if($('#addReference').hasClass('is-danger') && reference != ''){
            $('#addReference').removeClass('is-danger');
            $('#addReference').parent().next('p').fadeOut(200);
          }
          if($('#addDescription').hasClass('is-danger') && description != ''){
            $('#addDescription').removeClass('is-danger');
            $('#addDescription').parent().next('p').fadeOut(200);
          }
        if(valide == true){
          $.ajax({
            type: 'POST',
            url: link,
            data: sending,
            success: function(){
              nom = $('#addNom').val(''),
              reference = $('#addReference').val(''),
              description = $('#addDescription').val(''),
              $('#modal').fadeOut(200);
              getRecord();
              $.alert({
                icon: 'fa fa-success',
                type: 'green',
                title: 'Message',
                content: 'Action effectué avec succes',
                closeIcon: true,
                closeIconClass: 'fa fa-close',
                boxWidth: '30%',
                useBootstrap: false,
                draggable: true,
                animationBounce: 1.5,
                animationSpeed: 200,
                closeAnimation: 'right'
              });
            },
            error: function(jqxhr, string, error){
              $.alert({
                icon: 'fa fa-warning',
                type: 'red',
                title: string,
                content: 'Une erreur est survenu : ' + error,
                closeIcon: true,
                closeIconClass: 'fa fa-close',
                boxWidth: '30%',
                useBootstrap: false,
                draggable: true,
                animationBounce: 1.5,
                animationSpeed: 200,
                closeAnimation: 'right'
              });
            }
          });
        }
      })

      /*
      *
      *récupération de tous les résultats
      *
      */
        getRecord();
        function getRecord(){
          $.ajax({
            type: 'ajax',
            async: false,
            url: '<?php echo base_url();?>back/menu_parent/getRecord',
            dataType: 'json',
            success: function(data){
              var enregistrement = '';
              var i = 0;
              for(i = 0; i < data.length; i++){
                enregistrement += 
                '<tr>' + 
                      '<th>' + data[i].name + '</th>' +
                      '<td><a href="<?php echo base_url('/cuf/');?>' + data[i].reference + '"><?php echo base_url('/cuf/');?>' + data[i].reference + '</a></td>' +
                      '<td>' + data[i].type_contenu + '</td>' +
                      '<td class="has-text-centered">' +
                        '<div class="field is-grouped">' +
                          '<p class="control">' +
                            '<button class="button modal-button is-small is-info editRec" data-target="modalEdit" id="*' + data[i].id + '">' +
                              '<span class="icon">' + 
                                '<i class="fa fa-edit"></i>' + 
                              '</span>' +
                              '<span>Modifier</span>' +
                            '</button>' +
                          '</p>' +
                          '<p class="control">' +
                            '<button class="button is-danger is-small deleteRec" id="$' + data[i].id + '">' + 
                              '<span class="icon">' + 
                                '<i class="fa fa-trash"></i>' + 
                              '</span>' +
                              '<span>Supprimer</span>' +
                            '</button>' +
                          '</p>' +
                        '</div>' +
                      '</td>' +
                    '</tr>';
              }
              $('#dataTable').html(enregistrement);
            },
            error: function(jqxhr, string, error){
              $.alert({
                icon: 'fa fa-warning',
                type: 'red',
                title: string,
                content: 'Une erreur est survenu : ' + error,
                closeIcon: true,
                closeIconClass: 'fa fa-close',
                boxWidth: '30%',
                useBootstrap: false,
                draggable: true,
                animationBounce: 1.5,
                animationSpeed: 200,
                closeAnimation: 'right'
              });
            }
          });
        }


        /*
        *
        *Suppression de l'enregistrement
        *
        *
        *
        */

      $("#dataTable").on('click', '.deleteRec', function(){
        var reference = $(this);
        $.confirm({
          title: 'Suppression',
          icon: 'fa fa-warning',
          boxWidth: '30%',
          draggable: true,
          useBootstrap: false,
          closeIcon: true,
          closeIconClass: 'fa fa-close',
          animationBounce: 1.5,
          animationSpeed: 200,
          closeAnimation: 'right',
          type: 'orange',
          content: 'Proceder à la suppression de l\'enregistrement?',
          autoClose: 'cancel|5000',
          buttons: {
              yesButton: {
                text: 'Supprimer',
                btnClass: 'button is-warning',
                action: function(){
                  var id = reference.attr('id');
                  id = id.slice(1, id.length);
                  $.ajax({
                    type: 'post',
                    url: '<?php echo base_url();?>back/menu_parent/removeRecord/' + id,
                    success: function(){
                      reference.parent().parent().parent().parent().fadeOut(500);
                      $.alert({
                        icon: 'fa fa-success',
                        type: 'green',
                        title: 'Message',
                        content: 'Action effectué avec succes',
                        closeIcon: true,
                        closeIconClass: 'fa fa-close',
                        boxWidth: '30%',
                        useBootstrap: false,
                        draggable: true,
                        animationBounce: 1.5,
                        animationSpeed: 200,
                        closeAnimation: 'right'
                      });
                    },
                    error: function(jqxhr, string, error){
                      $.alert({
                        icon: 'fa fa-warning',
                        type: 'red',
                        title: string,
                        content: 'Une erreur est survenu : ' + error + ' ' + jqxhr,
                        closeIcon: true,
                        closeIconClass: 'fa fa-close',
                        boxWidth: '30%',
                        useBootstrap: false,
                        draggable: true,
                        animationBounce: 1.5,
                        animationSpeed: 200,
                        closeAnimation: 'right'
                      });
                    }
                  });
                }
              },
              cancel: {
                text: 'Annuler',
                btnClass: 'button is-info'
              }
          }
      });
        
      })

      /*
      *
      *
      *Génération de model de modification
      *
      *
      *
      */

      $('#dataTable').on('click', '.editRec', function(){
        var id = $(this).attr('id');
        id = id.slice(1, id.length);
        var $target = this.dataset.target;
        var target = $('#' + $target);
        $.ajax({
          type: 'GET',
          url: '<?php echo base_url();?>back/menu_parent/getRecord/' + id,
          dataType: 'json',
          success: function(data){
            var defaut = '', perso = '';
            text = data[0].type_contenu == 'text'?'selected="true"': '';
            custom = data[0].type_contenu == 'custom'?'selected="true"': '';
            var html = '<div class="modal-background"></div>' + 
            '<div class="modal-card">' + 
              '<header class="modal-card-head">' + 
                '<p class="modal-card-title">Menu parent</p>' + 
              '</header>' + 
              '<section class="modal-card-body">' + 
                '<div class="field">' + 
                  '<label class="label">Nom</label>' + 
                  '<p class="control has-icons-left">' + 
                    '<input class="input" type="text" name="editNom" id="editNom" placeholder="ex: Home" value="' + data[0].name + '">' + 
                    '<span class="icon is-small is-left">' + 
                      '<i class="fa fa-sitemap"></i>' + 
                    '</span>' + 
                  '</p>' + 
                '</div>' + 
                '<div class="field">' + 
                  '<label class="label">Référence</label>' + 
                  '<p class="control has-icons-left">' + 
                    '<input class="input" type="text" name="editReference" id="editReference" placeholder="ex: home/" value="' + data[0].reference + '">' + 
                    '<span class="icon is-small is-left">' + 
                      '<i class="fa fa-anchor"></i>' + 
                    '</span>' + 
                  '</p>' + 
                '</div>' + 
                '<div class="field">' + 
                '<label class="label">Type de menu</label>' + 
                '<div class="control has-icons-left is-expanded">' + 
                '<div class="select is-expanded">' + 
                '<select id="editType" name="editType">' + 
                '<option value="text" ' + text + '>Text</option>' + 
                '<option value="custom" ' + custom + ' >Custom</option>' + 
                '</select>' + 
                '</div>' + 
                '<div class="icon is-small is-left">' + 
                '<i class="fa fa-globe"></i>' + 
                '</div>' + 
                '</div>' + 
                '</div>' + 
                '<div class="field">' + 
                '<label class="label">Contenu du menu (si le type est "Text")</label>' + 
                '<div class="control">' + 
                '<textarea class="textarea ckeditor" name="editContenu" id="editContenu">' + data[0].contenu + '</textarea>' + 
                '</div>' + 
                '</div>' + 
                '<div class="field">' + 
                '<label class="label">Description du Menu</label>' + 
                '<div class="control">' + 
                '<textarea class="textarea" name="editDescription" id="editDescription" placeholder="Description du menu pour une réferencement au moteur de recherche">' + data[0].description + '</textarea>' + 
                '</div>' + 
                '</div>' + 
              '</section>' + 
              '<footer class="modal-card-foot">' + 
                '<button class="button is-success edit" id="*' + data[0].id + '" name="edit">Modifier</button>' + 
              '</footer>' + 
              '</div>' + 
              '<button class="modal-close is-large" aria-label="close"></button>';
            target.html(html);
            CKEDITOR.replace('editContenu');
          }
        });
        target.addClass('is-active');
        target.hide();
        target.fadeIn(200);
      });


      /*
      *
      *
      *Modification de l'enregistrement
      *
      *
      *
      */

      $('#modalEdit').on('click', '.edit', function(e){
        e.preventDefault();
        var id = $(this).attr('id');
        id = id.slice(1, id.length);
        var link = '<?php echo base_url('back/menu_parent/alterRecord/');?>' + id,
            nom = $('#editNom').val(),
            reference = $('#editReference').val(),
            type = $('#editType').val(),
            description = $('#editDescription').val(),
            contenu = CKEDITOR.instances['editContenu'].getData();
            sending = {
              'editNom': nom,
              'editReference': reference,
              'editType': type,
              'editContenu': contenu,
              'editDescription': description
            };
        $.ajax({
          type: 'POST',
          url: link,
          data: sending,
          success: function(){
            $('#modalEdit').fadeOut(200);
            getRecord();
            $.alert({
              icon: 'fa fa-success',
              type: 'green',
              title: 'Message',
              content: 'Action effectué avec succes',
              closeIcon: true,
              closeIconClass: 'fa fa-close',
              boxWidth: '30%',
              useBootstrap: false,
              draggable: true,
              animationBounce: 1.5,
              animationSpeed: 200,
              closeAnimation: 'right'
            });
          },
          error: function(jqxhr, string, error){
            $.alert({
              icon: 'fa fa-warning',
              type: 'red',
              title: string,
              content: 'Une erreur est survenu : ' + error,
              closeIcon: true,
              closeIconClass: 'fa fa-close',
              boxWidth: '30%',
              useBootstrap: false,
              draggable: true,
              animationBounce: 1.5,
              animationSpeed: 200,
              closeAnimation: 'right'
            });
          }
        });
      })
    </script>
</body>
</html>