
          <div class="box">
            <div class="field is-grouped">
              <p class="control">
                <button class="button block modal-button is-success" id="addRecord" data-target="addModal">
                  <span class="icon">
                    <i class="fa fa-plus"></i>
                  </span>
                  <span>Nouvel évenement</span>
                </button>
              </p>
              <p class="control">
                <button class="button block modal-button is-success" id="addType1" data-target="typeModal">
                  <span class="icon">
                    <i class="fa fa-star-half-empty"></i>
                  </span>
                  <span>Type d'évenement</span>
                </button>
              </p>
            </div>
            <div id="addModal" class="modal text">
              <div class="modal-background"></div>
              <div class="modal-card" width="1000">
                <header class="modal-card-head">
                  <p class="modal-card-title">Menu parent</p>
                </header>
                <section class="modal-card-body">
                  <form>
                    <div class="field">
                      <label class="label">Nom</label>
                      <p class="control has-icons-left">
                        <input class="input" type="text" name="nom" id="nom" placeholder="ex: Home">
                        <span class="icon is-small is-left">
                          <i class="fa fa-sitemap"></i>
                        </span>
                      </p>
                    </div>
                    <div class="field">
                      <label class="label">Référence</label>
                      <p class="control has-icons-left">
                        <input class="input" type="text" name="reference" id="reference" placeholder="ex: home/">
                        <span class="icon is-small is-left">
                          <i class="fa fa-anchor"></i>
                        </span>
                      </p>
                    </div>
                    <div class="field">
                      <label class="label">Type de menu</label>
                      <div class="control has-icons-left is-expanded">
                        <div class="select is-expanded">
                          <select>
                            <option value=''>Défaut</option>
                            <option>Personnalisé</option>
                          </select>
                        </div>
                        <div class="icon is-small is-left">
                          <i class="fa fa-globe"></i>
                        </div>
                      </div>
                    </div>
                    <div class="field">
                      <label class="label">Description du Menu</label>
                      <div class="control">
                          <textarea class="textarea" name="description" placeholder="Description du menu pour une réferencement au moteur de recherche"></textarea>
                      </div>
                    </div>
                  </form>
                </section>
                <footer class="modal-card-foot">
                  <button class="button is-success">Enregistrer</button>
                  <button class="button">Annuler</button>
                </footer>
              </div>
              <button class="modal-close is-large" aria-label="close"></button>
            </div>

            <form action="">
              <div class="modal" id="typeModal">
                <div class="modal-background"></div>
                <div class="modal-content box">
                  <p class="subtitle is-2">Libelle</p>
                  <div class="field is-grouped is-grouped-multiline" id="dataTag">
                    
                  </div>
                  <form method="POST">
                    <div class="field has-addons">
                      <p class="control is-expanded"> 
                        <input name="addLibelle" id="addLibelle" class="input" type="text" placeholder="Libelle"> 
                      </p> 
                      <p class="control"> 
                        <button id="addTag" class="button is-primary">Ajouter</button>
                      </p> 
                    </div>
                  </form>
                </div>
              </div>
            </form>


              <table class="table is-narrow is-fullwidth">
                <thead>
                  <tr>
                    <th><abbr title="Titre de l'évenement">Titre</abbr></th>
                    <th><abbr title="Type de l'évenement">Type</abbr></th>
                    <th><abbr title="Date de déroulement">Date</abbr></th>
                    <th>Lieu</th>
                    <th><abbr title="Détail de tous ce qui touche à l'évenement">Détail</abbr></th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody id="dataTable">
                  <tr>
                    <th>Fête national</th>
                    <td>Fête</td>
                    <td>26 Juin 2019</td>
                    <td>Stade Fianarantsoa</td>
                    <td></td>
                    <td class="has-text-centered">
                      <div class="field is-grouped">
                        <p class="control">
                          <button class="button modal-button is-small is-info" data-target="modal">Modifier</button>
                        </p>
                        <p class="control">
                          <button class="button is-danger is-small">Supprimer</button>
                        </p>
                      </td>
                  </tr>
                </tbody>
              </table>
              <nav class="pagination" role="navigation" aria-label="pagination">
                <a class="pagination-previous" title="This is the first page" disabled>Previous</a>
                <a class="pagination-next">Next page</a>
                <ul class="pagination-list">
                  <li>
                    <a class="pagination-link is-current" aria-label="Page 1" aria-current="page">1</a>
                  </li>
                  <li>
                    <a class="pagination-link" aria-label="Goto page 2">2</a>
                  </li>
                  <li>
                    <a class="pagination-link" aria-label="Goto page 3">3</a>
                  </li>
                </ul>
              </nav>
          </div>
      </div>
    </div>
</body>

</html>
