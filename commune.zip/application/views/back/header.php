<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Back office Tableau de bord</title>
    <link rel="stylesheet" href="<?php echo css_url('font-awesome'); ?>" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo css_url('jquery-confirm.min');?>">
    <script type="text/javascript" src="<?php echo js_url('jquery');?>"></script>
    <!-- Bulma Version 0.7.2-->
    <style type="text/css">
      .folder-icon{
        background: url('<?php echo img_url('folder', 'png');?>');
      }
      .folder:hover .folder-icon{
        background: url('<?php echo img_url('folder-open', 'png');?>');
      }
    </style>
    <link rel="stylesheet" href="<?php echo css_url('bulma'); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo css_url('style'); ?>">
</head>

<body>

    <!-- START NAV -->
    <nav class="navbar is-primary block">
      <div class="container">
        <div class="navbar-brand">
          <a href="">
            <?php echo image('logo', 'png', 'Commune Urbaine de Fianarantsoa', array('width' => 150)) ?>
          </a>
          <div class="navbar-burger burger" data-target="log">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
        <div id="log" class="navbar-menu">
          <div class="navbar-end">
            <div class="navbar-item has-dropdown is-hoverable">
              <a href="" class="navbar-link">
                <figure class="image is-32x32" style="margin-right:.5em;">
                  <?php echo image('user', 'png'); ?>
                </figure>
                Admin
              </a>
              <div class="navbar-dropdown">
                <a href="" class="navbar-item">Profile</a>
                <a href="" class="navbar-item">Déconnexion</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
    <!-- END NAV -->
    <div class="container">
      <div class="columns">
        <div class="column is-3">
          <aside class="menu is-hidden-mobile box">
            <p class="menu-label">
              Général
            </p>
            <ul class="menu-list">
              <li><a href="<?php echo site_url('back/dashboard') ?>" class=""><strong>Tableau de bord</strong></a></li>
            </ul>
            <p class="menu-label">
              Site
            </p>
            <ul class="menu-list">
              <li>
                <a><strong>Menu</strong></a>
                <ul>
                  <li><a href="<?php echo site_url('back/menu_parent') ?>" ><strong>Menu parent</strong></a></li>
                  <li><a href="<?php echo site_url('back/sous_menu') ?>" ><strong>Sous-menu</strong></a></li>
                </ul>
              </li>
              <li><a href="<?php echo site_url('back/article') ?>" ><strong>Articles</strong></a></li>
              <li><a href="<?php echo site_url('back/evenement') ?>" ><strong>Evenements</strong></a></li>
              <li><a href="<?php echo site_url('back/lieu') ?>" ><strong>Lieux marquants</strong></a></li>
              <li>
                <a><strong>Photos</strong></a>
                <ul>
                  <li><a href="<?php echo site_url('back/album') ?>" ><strong>Album</strong></a></li>
                  <li><a href="<?php echo site_url('back/image') ?>" ><strong>Image</strong></a></li>
                </ul>
              </li>
              <li><a href="<?php echo site_url('back/document') ?>" ><strong>Documents</strong></a></li>
            </ul>
            <p class="menu-label">
              Administrations
            </p>
            <ul class="menu-list">
              <li><a href="<?php echo site_url('back/utilisateur') ?>" ><strong>Utilisateurs</strong></a></li>
              <li><a href="<?php echo site_url('back/message') ?>" ><strong>Message</strong></a></li>
            </ul>
          </aside>
        </div>
        <div class="column is-9">