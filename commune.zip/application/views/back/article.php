
          <div class="box">
            <div class="field is-grouped">
              <p class="control">
                <button class="button block modal-button is-success addRec" id="addRecord" data-target="modal">
                  <span class="icon">
                    <i class="fa fa-plus"></i>
                  </span>
                  <span>Nouvel article</span>
                </button>
              </p>
              <p class="control">
                <button class="button block modal-button is-success addRec" id="addType1" data-target="typeModal">
                  <span class="icon">
                    <i class="fa fa-book"></i>
                  </span>
                  <span>Type d'article</span>
                </button>
              </p>
            </div>
            
            <form action="">
              <div class="modal" id="typeModal">
                <div class="modal-background"></div>
                <div class="modal-content box">
                  <p class="subtitle is-2">Libelle</p>
                  <div class="field is-grouped is-grouped-multiline" id="dataTag">
                    
                  </div>
                  <form method="POST">
                    <div class="field has-addons">
                      <p class="control is-expanded"> 
                        <input name="addLibelle" id="addLibelle" class="input" type="text" placeholder="Libelle"> 
                      </p> 
                      <p class="control"> 
                        <button id="addTag" class="button is-primary">Ajouter</button>
                      </p> 
                    </div>
                  </form>
                </div>
              </div>
            </form>

            <form action="" method="POST">
              <div id="modal" class="modal big-modal">
                <div class="modal-background"></div>
                <div class="modal-card">
                  <header class="modal-card-head">
                    <p class="modal-card-title">Article</p>
                  </header>
                  <section class="modal-card-body">
                      <div class="field">
                        <label class="label">Titre</label>
                        <p class="control has-icons-left">
                          <input class="input" type="text" name="addTitre" id="addTitre">
                          <span class="icon is-small is-left">
                            <i class="fa fa-newspaper-o"></i>
                          </span>
                        </p>
                        <p class="help is-danger" style="display: none;">Une article a besoin de titre</p>
                      </div>

                      <div class="field">
                        <label class="label">Image de couverture</label>
                        <div class="file is-info has-name is-fullwidth is-right">
                          <label class="file-label">
                            <input class="file-input is-danger" type="file" name="couverture" id="couverture">
                            <span class="file-cta">
                              <span class="file-icon">
                                <i class="fa fa-upload"></i>
                              </span>
                              <span class="file-label">
                                Choisir une image
                              </span>
                            </span>
                            <span class="file-name" id="addImage">Nom du fichier</span>
                          </label>
                        </div>
                      </div>

                      <div class="box is-offset-4 column is-4" id="view" style="display: none;">
                        <div class="field is-grouped is-grouped-right">
                          <div class="control">
                            <button class="delete closeView"></button>
                          </div>
                        </div>
                        <div class="">
                          <figure class="image is-3by2">
                            
                          </figure>
                        </div>
                      </div>

                      <div class="field">
                        <label class="label">Type d'actualité</label>
                        <div class="control has-icons-left is-expanded">
                          <div class="select is-expanded">
                            <select id="addType" name="addType">
                            </select>
                          </div>
                          <div class="icon is-small is-left">
                            <i class="fa fa-globe"></i>
                          </div>
                        </div>
                      </div>

                      <div class="field">
                        <label class="label">Corp de l'article</label>
                        <div class="control">
                            <textarea class="textarea" name="addContenu" id="addContenu"></textarea>
                        </div>
                      </div>

                  </section>
                  <footer class="modal-card-foot">
                    <button class="button is-success" id="save" name="save">Enregistrer</button>
                    <input type="button" class="button is-danger" id="reset" value="Annuler">
                  </footer>
                </div>
                <button class="modal-close is-large" aria-label="close"></button>
              </div>
            </form>

          <form action="" method="POST">
            <div id="modalEdit" class="modal big-modal editRecord">
              
            </div>
          </form>

          <div id="modalView" class="modal">
            <div class="modal-background"></div>
            <div class="modal-content is-boxed has-background-white">
              <div class="box">
                
              </div>
            </div>
            <button class="modal-close is-large" aria-label="close"></button>
          </div>


              <table class="table is-narrow is-fullwidth">
                <thead>
                  <tr>
                    <th><abbr title="Nom de l'éditeur">Editeur</abbr></th>
                    <th><abbr title="Type de l'article">Section</abbr></th>
                    <th><abbr title="Titre de l'article">Titre</abbr></th>
                    <th><abbr title="Date de la publication">Publication</abbr></th>
                    <th class="has-text-centered">Action</th>
                  </tr>
                </thead>
                <tbody id="dataTable">
                  
                </tbody>
              </table>
              <nav class="pagination" role="navigation" aria-label="pagination">
                <a class="pagination-previous" title="This is the first page" disabled>Previous</a>
                <a class="pagination-next">Next page</a>
                <ul class="pagination-list">
                  <li>
                    <a class="pagination-link is-current" aria-label="Page 1" aria-current="page">1</a>
                  </li>
                  <li>
                    <a class="pagination-link" aria-label="Goto page 2">2</a>
                  </li>
                  <li>
                    <a class="pagination-link" aria-label="Goto page 3">3</a>
                  </li>
                </ul>
              </nav>
          </div>
      </div>
    </div>
    <script type="text/javascript">
      /*
      *
      *
      *
      *
      *Chargement de contenu au click
      *
      *
      *
      */

      $('#dataTable').on('click', '.viewRec', function(e){
        e.preventDefault();
        var content = $('#modalView .modal-content .box'),
        id = $(this).attr('id');
        id = id.slice(1, id.length);
        var link = '<?php echo base_url('back/article/getView/')?>' + id;
        $.ajax({
          type: 'get',
          url: link,
          dataType: 'json',
          success: function(data){
            var html = '',
            imageRoot = '<?php echo base_url("assets/img/article/couverture/")?>';
            html += 
            '<h1 class="title is-2" style="font-weight: 600;">' + 
                data[0].titre + 
            '</h1>' + 
            '<div class="content">' +
                '<img src="' + imageRoot + data[0].image + '" style="width: 100%; max-width: 300px; float: left; margin: 0 20px 20px 0;">' +
                '<div style="text-align: justify;">' +
                    data[0].contenu + 
                '<p class="has-text-right"><i><strong>' + data[0].nom + ' ' + data[0].prenom + '</strong></i></p>' +
                '</div>' +
            '</div>';
            content.html(html);
          }
        })
      })

      $('#modalEdit').on('change',  '.file-input', function(){
        var valide = true,
        errorMessage = '',
        lastFile = $('#editImage').html() != 'Nom du fichier'? $('#editImage').html(): '';
        if(lastFile != ''){
          console.log()
          var link = '<?php echo base_url('back/article/removeCover/')?>' + lastFile,
            reference = $('.closeView');
          $.ajax({
            type: 'get',
            url: link,
            success: function(){
              reference.parent().parent().parent().slideUp(300, function(){
                var image = document.getElementById('editCouverture').files[0],
                nomImage = image.name,
                extensionImage = nomImage.split('.').pop().toLowerCase(),
                troncature = nomImage.split('.')[1],
                tailleImage = Math.floor(image.size / 1024);
                if(jQuery.inArray(extensionImage, ['gif', 'png', 'jpg', 'jpeg']) == -1){
                  valide = false;
                  errorMessage += ' - Le type d\'image n\'est pas pris en charge<br>';
                }
                if(jQuery.inArray(troncature, ['gif', 'png', 'jpg', 'jpeg']) == -1){
                    valide = false;
                    errorMessage += ' - Le nom de fichier ne doit pas contenir de point<br>';
                  }
                if(tailleImage > 7 * 1024){
                  valide = false;
                  errorMessage += ' - La taille du fichier est trop grand<br>';
                }
                if(valide == true){
                  var formData = new FormData(),
                  link = '<?php echo base_url('back/article/addCover/')?>';
                  formData.append('couverture', image);
                  $.ajax({
                    url: link,
                    method: 'POST',
                    data: formData,
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function(){
                      var image = '<img src="<?php echo base_url('assets/img/tmp/\' + nomImage + \'');?>">';
                      $('#editView figure').html(image);
                      $('#editView').slideDown();
                    },
                    error: function(jqxhr, string, error){
                      alert(error + '\n' + string);
                    }
                  })
                }else{
                  $('#addImage').html('Nom du fichier');
                  $('#couverture').val('');
                  $.alert({
                    title: 'Erreur',
                    content: errorMessage,
                    type: 'red',
                    useBootstrap: false,
                    buttons: {
                      confirm: {
                        text: 'Reessayer',
                        action: function(){
                          $('#couverture').click();
                        },
                      }
                    },
                  });
                }
              });
            }
          });
        }else{
          var image = this.files[0],
          nomImage = image.name,
          extensionImage = nomImage.split('.').pop().toLowerCase(),
          troncature = nomImage.split('.')[1],
          tailleImage = Math.floor(image.size / 1024);
          if(jQuery.inArray(extensionImage, ['gif', 'png', 'jpg', 'jpeg']) == -1){
            valide = false;
            errorMessage += ' - Le type d\'image n\'est pas pris en charge<br>';
          }
          if(jQuery.inArray(troncature, ['gif', 'png', 'jpg', 'jpeg']) == -1){
              valide = false;
              errorMessage += ' - Le nom de fichier ne doit pas contenir de point<br>';
            }
          if(tailleImage > 7 * 1024){
            valide = false;
            errorMessage += ' - La taille du fichier est trop grand<br>';
          }
          if(valide == true){
            var formData = new FormData(),
            link = '<?php echo base_url('back/article/addCover/')?>';
            formData.append('couverture', image);
            $.ajax({
              url: link,
              method: 'POST',
              data: formData,
              contentType: false,
              cache: false,
              processData: false,
              success: function(){
                var image1 = '<?php echo image('article/couverture/\' + nomImage + \'')?>';
                var image = '<img src="<?php echo base_url('assets/img/tmp/\' + nomImage + \'');?>">';
                $('#view figure').html(image);
                $('#view').slideDown();
              },
              error: function(jqxhr, string, error){
                alert(error + '\n' + string);
              }
            })
          }else{
            $('#editImage').html('Nom du fichier');
            $('#editCouverture').val('');
            $.alert({
              title: 'Erreur',
              content: errorMessage,
              type: 'red',
              useBootstrap: false,
              buttons: {
                confirm: {
                  text: 'Reessayer',
                  action: function(){
                    $('#couverture').click();
                  },
                }
              },
            });
          }
        }
      })

      $('#addType1').click(function(){
        getType();
      })

      $('#addRecord').click(function(){
        CKEDITOR.replace('addContenu');
        var reference = $('#addType');
        $.ajax({
          type: 'get',
          url: '<?php echo base_url('')?>back/article/getType',
          dataType: 'json',
          success: function(data){
            var html = '';
            for(var i = 0; i < data.length; i++){
              html += '<option value="' + data[i].id + '">' + data[i].libelle + '</option>';
            }
            reference.html(html);
          }
        });
      })

      $('#dataTable').on('click', '.editRec', function(){
        var id = $(this).attr('id');
        id = id.slice(1, id.length);
        var $target = this.dataset.target;
        var target = $('#' + $target);
        $.ajax({
          type: 'GET',
          url: '<?php echo base_url();?>back/article/getRecord/' + id,
          dataType: 'json',
          success: function(data){
            var text = '', custom = '';
            // text = data[0].type_contenu == 'text'?'selected="true"': '';
            // custom = data[0].type_contenu == 'custom'?'selected="true"': '';
            var html = '<div class="modal-background"></div>' + 
                '<div class="modal-card">' + 
                  '<header class="modal-card-head">' + 
                    '<p class="modal-card-title">Article</p>' + 
                  '</header>' + 
                  '<section class="modal-card-body">' + 
                      '<div class="field">' + 
                        '<label class="label">Titre</label>' + 
                        '<p class="control has-icons-left">' + 
                          '<input class="input" type="text" name="editTitre" id="editTitre" value="' + data[0].titre + '">' + 
                          '<span class="icon is-small is-left">' + 
                            '<i class="fa fa-newspaper-o"></i>' + 
                          '</span>' + 
                        '</p>' + 
                        '<p class="help is-danger" style="display: none;">Une article a besoin de titre</p>' + 
                      '</div>' + 

                      '<div class="field">' + 
                        '<label class="label">Image de couverture</label>' + 
                        '<div class="file is-info has-name is-fullwidth is-right">' + 
                          '<label class="file-label">' + 
                            '<input class="file-input is-danger" type="file" name="editCouverture" id="editCouverture">' + 
                            '<span class="file-cta">' + 
                              '<span class="file-icon">' + 
                                '<i class="fa fa-upload"></i>' + 
                              '</span>' + 
                              '<span class="file-label">' + 
                                'Choisir une image' + 
                              '</span>' + 
                            '</span>' + 
                            '<span class="file-name" id="editImage">' + data[0].image +  '</span>' + 
                            '<span id="lastFile" style="display: none;">' + data[0].image + '</span>' + 
                          '</label>' + 
                        '</div>' + 
                      '</div>' + 

                      '<div class="box is-offset-4 column is-4" id="editView">' + 
                        '<div class="field is-grouped is-grouped-right">' + 
                          '<div class="control">' + 
                            '<button class="delete closeView"></button>' + 
                          '</div>' + 
                        '</div>' + 
                        '<div class="">' + 
                          '<figure class="image is-3by2">' + 
                            '<img src="<?php echo base_url('assets/img/article/couverture/');?>' + data[0].image + '">' + 
                          '</figure>' + 
                        '</div>' + 
                      '</div>' + 

                      '<div class="field">' + 
                        '<label class="label">Type d\'actualité</label>' + 
                        '<div class="control has-icons-left is-expanded">' + 
                          '<div class="select is-expanded">' + 
                            '<select id="editType" name="editType">' + 

                            '</select>' + 
                          '</div>' + 
                          '<div class="icon is-small is-left">' + 
                            '<i class="fa fa-globe"></i>' + 
                          '</div>' + 
                        '</div>' + 
                      '</div>' + 

                      '<div class="field">' + 
                        '<label class="label">Corp de l\'article</label>' + 
                        '<div class="control">' + 
                            '<textarea class="textarea ckeditor" name="editContenu" id="editContenu">' + data[0].contenu + '</textarea>' + 
                        '</div>' + 
                      '</div>' + 

                  '</section>' + 
                  '<footer class="modal-card-foot">' + 
                    '<button class="button is-success edit" id="*' + data[0].id1 + '" name="edit">Modifier</button>' + 
                  '</footer>' + 
                '</div>' + 
                '<button class="modal-close is-large" aria-label="close"></button>'; + 
            target.html(html);
            CKEDITOR.replace('editContenu');
            link = '<?php echo base_url('')?>back/article/getType';
            $.ajax({
              type: 'get',
              url: link,
              dataType: 'json',
              success: function(donnee){
                var html = '',
                match = '';
                for(var i = 0; i < donnee.length; i++){
                  match = donnee[i].id == data[0].type_actualite_id?'selected="true"': '';
                  html += 
                  '<option value="' + donnee[i].id + '" ' + match + '>' + donnee[i].libelle + '</option>';;
                }
                $('#editType').html(html);
              },
              error: function(){
                alert('Oups');
              }
            });
          },
          error: function(jqxhr, string, error){
            $.alert({
              icon: 'fa fa-warning',
              type: 'red',
              title: string,
              content: 'Une erreur est survenu : ' + error,
              closeIcon: true,
              closeIconClass: 'fa fa-close',
              boxWidth: '30%',
              useBootstrap: false,
              draggable: true,
              animationBounce: 1.5,
              animationSpeed: 300,
              closeAnimation: 'right'
            });
          }
        });
        target.addClass('is-active');
        target.hide();
        target.fadeIn(300);
      });

      /*
      *
      *
      *
      *Récuépration de tous les enregistrements
      *
      *
      *
      *
      */
      getRecord();
      function getRecord(){
        var link = '<?php echo base_url('')?>back/article/getRecord';
        $.ajax({
          type: 'get',
          url: link,
          dataType: 'json',
          success: function(data){
            var html = '';
            for(var i = 0; i < data.length; i++){
              html += 
              '<tr>' +
                '<td>' + data[i].nom + ' ' + data[i].prenom + '</td>' + 
                '<td>' + data[i].libelle + '</td>' + 
                '<th>' + data[i].titre + '</th>' + 
                '<td>' + data[i].publication_complet + '</td>' + 
                '<td>' +
                  '<div class="field is-grouped">' +
                    '<p class="control">' +
                      '<button class="button modal-button is-small is-warning viewRec" data-target="modalView" id="!' + data[i].id1 + '">' +
                        '<span class="icon is-large">' + 
                          '<i class="fa fa-expand"></i>' + 
                        '</span>' +
                        '<span>Aperçu</span>' +
                      '</button>' +
                    '</p>' +
                    '<p class="control">' +
                      '<button class="button modal-button is-small is-info editRec" data-target="modalEdit" id="*' + data[i].id1 + '">' +
                        '<span class="icon">' + 
                          '<i class="fa fa-edit"></i>' + 
                        '</span>' +
                        '<span>Modifier</span>' +
                      '</button>' +
                    '</p>' +
                    '<p class="control">' +
                      '<button class="button is-danger is-small deleteRec" id="$' + data[i].id1 + '">' + 
                        '<span class="icon">' + 
                          '<i class="fa fa-trash"></i>' + 
                        '</span>' +
                        '<span>Supprimer</span>' +
                      '</button>' +
                    '</p>' +
                  '</div>' +
                '</td>' + 
              '</tr>';
            };
            $('#dataTable').html(html);
          }
        });
      }

      function getType(){
        var link = '<?php echo base_url('')?>back/article/getType';
        $.ajax({
          type: 'get',
          url: link,
          dataType: 'json',
          success: function(data){
            var html = '';
            for(var i = 0; i < data.length; i++){
              html += 
              '<div class="control">' + 
                '<div class="tags has-addons">' +
                  '<span class="tag is-black">' + data[i].libelle + '</span>' +
                  '<a id="$' + data[i].id + '" class="tag delete is-medium is-danger"></a>' +
                '</div>' +
              '</div>';
            }
            $('#dataTag').html(html);
          },
          error: function(){
            alert('Oups');
          }
        });
      }

      /*
      *
      *
      *
      *
      *Suppression
      *
      *
      *
      *
      */

      $("#dataTable").on('click', '.deleteRec', function(){
          var reference = $(this);
          $.confirm({
            title: 'Suppression',
            icon: 'fa fa-warning',
            boxWidth: '30%',
            draggable: true,
            useBootstrap: false,
            closeIcon: true,
            closeIconClass: 'fa fa-close',
            animationBounce: 1.5,
            animationSpeed: 300,
            closeAnimation: 'right',
            type: 'orange',
            content: 'Proceder à la suppression de l\'enregistrement?',
            autoClose: 'cancel|5000',
            buttons: {
                yesButton: {
                  text: 'Supprimer',
                  btnClass: 'button is-warning',
                  action: function(){
                    var id = reference.attr('id');
                    id = id.slice(1, id.length);
                    $.ajax({
                      type: 'get',
                      url: '<?php echo base_url();?>back/article/removeRecord/' + id,
                      success: function(){
                        reference.parent().parent().parent().parent().fadeOut();
                      },
                      error: function(jqxhr, string, error){
                        $.alert({
                          icon: 'fa fa-warning',
                          type: 'red',
                          title: string,
                          content: 'Une erreur est survenu : ' + error,
                          closeIcon: true,
                          closeIconClass: 'fa fa-close',
                          boxWidth: '30%',
                          useBootstrap: false,
                          draggable: true,
                          animationBounce: 1.5,
                          animationSpeed: 300,
                          closeAnimation: 'right'
                        });
                      }
                    });
                  }
                },
                cancel: {
                  text: 'Annuler',
                  btnClass: 'button is-info'
                }
            }
          });
        })

      $('.closeView').click(function(e){
        e.preventDefault();
        var fichier = document.getElementById('couverture').files[0].name,
            link = '<?php echo base_url('back/article/removeCover/')?>' + fichier,
            reference = $(this);
        $.ajax({
          type: 'get',
          url: link,
          success: function(){
            reference.parent().parent().parent().slideUp();
            $('#addImage').html('Nom du fichier');
          }
        })
      })

      $('#modalEdit').on('click', '.closeView', function(e){
        e.preventDefault();
        var fichier = document.querySelector('#modalEdit #editCouverture'),
            link = '<?php echo base_url('back/article/removeCover/')?>',
            reference = $(this);
            console.log(fichier);
            if(fichier.files[0] != null){
              fichier = fichier.files[0].name;
              link += fichier;
              $.ajax({
                type: 'get',
                url: link,
                success: function(){
                  reference.parent().parent().parent().slideUp();
                  $('#editImage').html('Nom du fichier');
                }
              });
            }else{
              reference.parent().parent().parent().slideUp();
              $('#editImage').html('Nom du fichier');
            }
        
      })

      $('#dataTag').on('click', '.delete', function(e){
        e.preventDefault();
        var reference = $(this);
        $.confirm({
            title: 'Suppression',
            icon: 'fa fa-warning',
            boxWidth: '30%',
            draggable: true,
            useBootstrap: false,
            closeIcon: true,
            closeIconClass: 'fa fa-close',
            animationBounce: 1.5,
            animationSpeed: 300,
            closeAnimation: 'right',
            type: 'orange',
            content: 'Proceder à la suppression de l\'enregistrement?',
            autoClose: 'cancel|5000',
            buttons: {
                yesButton: {
                  text: 'Supprimer',
                  btnClass: 'button is-warning',
                  action: function(){
                    var id = reference.attr('id');
                    id = id.slice(1, id.length);
                    $.ajax({
                      type: 'post',
                      url: '<?php echo base_url();?>back/article/removeType/' + id,
                      success: function(){
                        reference.parent().parent().fadeOut(300);
                        // $.alert({
                        //   icon: 'fa fa-success',
                        //   type: 'green',
                        //   title: 'Message',
                        //   content: 'Action effectué avec succes',
                        //   closeIcon: true,
                        //   closeIconClass: 'fa fa-close',
                        //   boxWidth: '30%',
                        //   useBootstrap: false,
                        //   draggable: true,
                        //   animationBounce: 1.5,
                        //   animationSpeed: 300,
                        //   closeAnimation: 'right'
                        // });
                      },
                      error: function(jqxhr, string, error){
                        $.alert({
                          icon: 'fa fa-warning',
                          type: 'red',
                          title: string,
                          content: 'Une erreur est survenu : ' + error,
                          closeIcon: true,
                          closeIconClass: 'fa fa-close',
                          boxWidth: '30%',
                          useBootstrap: false,
                          draggable: true,
                          animationBounce: 1.5,
                          animationSpeed: 300,
                          closeAnimation: 'right'
                        });
                      }
                    });
                  }
                },
                cancel: {
                  text: 'Annuler',
                  btnClass: 'button is-info'
                }
            }
          });
      });

      /*
      *
      *
      *
      *
      *
      *Ajout et Modification de donnée
      *
      *
      *
      *
      */

      $('#modalEdit').on('click', '.edit', function(e){
        e.preventDefault();
        var id = $(this).attr('id');
        id = id.slice(1, id.length);
        var link = '<?php echo base_url('back/article/alterRecord/')?>' + id,
        editTitre = $('#editTitre').val(),
        editType = $('#editType').val(),
        editImage = $('#editImage').html(),
        editContenu = CKEDITOR.instances['editContenu'].getData(),
        oldImage = $('#lastFile').text(),
        sending = {
          'editTitre' : editTitre,
          'editType' : editType,
          'editImage' : editImage,
          'editContenu' : editContenu,
          'oldImage': oldImage
        };
        $.ajax({
          url: link,
          type: 'post',
          data: sending,
          success: function(){
            $('.modal-background').click();
            getRecord();
          },
          error: function(jqxhr, string, error){
            $.alert({
              icon: 'fa fa-warning',
              type: 'red',
              title: string,
              content: 'Une erreur est survenu : ' + error,
              closeIcon: true,
              closeIconClass: 'fa fa-close',
              boxWidth: '30%',
              useBootstrap: false,
              draggable: true,
              animationBounce: 1.5,
              animationSpeed: 300,
              closeAnimation: 'right'
            });
          }
        });
      })

      $('#save').click(function(e){
        e.preventDefault();
        var link = '<?php echo base_url('back/article/addRecord')?>',
        addTitre = $('#addTitre').val(),
        addType = $('#addType').val(),
        addImage = $('#addImage').html(),
        addContenu = CKEDITOR.instances['addContenu'].getData(),
        sending = {
          'addTitre' : addTitre,
          'addType' : addType,
          'addImage' : addImage,
          'addContenu' : addContenu
        };
        $.ajax({
          url: link,
          type: 'post',
          data: sending,
          success: function(){
            $('#addTitre').val('');
            $('#addImage').html('Nom du fichier');
            $('.closeView').parent().parent().parent().slideUp();
            $('#couverture').val('');
            $('.modal-background').click();
            CKEDITOR.instances['addContenu'].destroy(true);
            getRecord();
          },
          error: function(jqxhr, string, error){
            $.alert({
              icon: 'fa fa-warning',
              type: 'red',
              title: string,
              content: 'Une erreur est survenu : ' + error,
              closeIcon: true,
              closeIconClass: 'fa fa-close',
              boxWidth: '30%',
              useBootstrap: false,
              draggable: true,
              animationBounce: 1.5,
              animationSpeed: 300,
              closeAnimation: 'right'
            });
          }
        });
      });


      $('#couverture').change(function(){
        var valide = true,
        errorMessage = '',
        lastFile = $('#addImage').html() != 'Nom du fichier'? $('#addImage').html(): '';
        if(lastFile != ''){
          console.log('loaded');
          var link = '<?php echo base_url('back/article/removeCover/')?>' + lastFile,
            reference = $('.closeView');
          $.ajax({
            type: 'get',
            url: link,
            success: function(){
              reference.parent().parent().parent().slideUp(300, function(){
                var image = document.getElementById('couverture').files[0],
                nomImage = image.name,
                extensionImage = nomImage.split('.').pop().toLowerCase(),
                troncature = nomImage.split('.')[1],
                tailleImage = Math.floor(image.size / 1024);
                if(jQuery.inArray(extensionImage, ['gif', 'png', 'jpg', 'jpeg']) == -1){
                  valide = false;
                  errorMessage += ' - Le type d\'image n\'est pas pris en charge<br>';
                }
                if(jQuery.inArray(troncature, ['gif', 'png', 'jpg', 'jpeg']) == -1){
                    valide = false;
                    errorMessage += ' - Le nom de fichier ne doit pas contenir de point<br>';
                  }
                if(tailleImage > 7 * 1024){
                  valide = false;
                  errorMessage += ' - La taille du fichier est trop grand<br>';
                }
                if(valide == true){
                  var formData = new FormData(),
                  link = '<?php echo base_url('back/article/addCover/')?>';
                  formData.append('couverture', image);
                  $.ajax({
                    url: link,
                    method: 'POST',
                    data: formData,
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function(){
                      var image = '<img src="<?php echo base_url('assets/img/tmp/\' + nomImage + \'');?>">';
                      $('#view figure').html(image);
                      $('#view').slideDown();
                    },
                    error: function(jqxhr, string, error){
                      alert(error + '\n' + string);
                    }
                  })
                }else{
                  $('#addImage').html('Nom du fichier');
                  $('#couverture').val('');
                  $.alert({
                    title: 'Erreur',
                    content: errorMessage,
                    type: 'red',
                    useBootstrap: false,
                    buttons: {
                      confirm: {
                        text: 'Reessayer',
                        action: function(){
                          $('#couverture').click();
                        },
                      }
                    },
                  });
                }
              });
            }
          });
        }else{
          var image = this.files[0],
          nomImage = image.name,
          extensionImage = nomImage.split('.').pop().toLowerCase(),
          troncature = nomImage.split('.')[1],
          tailleImage = Math.floor(image.size / 1024);
          if(jQuery.inArray(extensionImage, ['gif', 'png', 'jpg', 'jpeg']) == -1){
            valide = false;
            errorMessage += ' - Le type d\'image n\'est pas pris en charge<br>';
          }
          if(jQuery.inArray(troncature, ['gif', 'png', 'jpg', 'jpeg']) == -1){
              valide = false;
              errorMessage += ' - Le nom de fichier ne doit pas contenir de point<br>';
            }
          if(tailleImage > 7 * 1024){
            valide = false;
            errorMessage += ' - La taille du fichier est trop grand<br>';
          }
          if(valide == true){
            var formData = new FormData(),
            link = '<?php echo base_url('back/article/addCover/')?>';
            formData.append('couverture', image);
            $.ajax({
              url: link,
              method: 'POST',
              data: formData,
              contentType: false,
              cache: false,
              processData: false,
              success: function(){
                var image = '<img src="<?php echo base_url('assets/img/tmp/\' + nomImage + \'');?>">';
                $('#view figure').html(image);
                $('#view').slideDown();
              },
              error: function(jqxhr, string, error){
                alert(error + '\n' + string);
              }
            })
          }else{
            $('#addImage').html('Nom du fichier');
            $('#couverture').val('');
            $.alert({
              title: 'Erreur',
              content: errorMessage,
              type: 'red',
              useBootstrap: false,
              buttons: {
                confirm: {
                  text: 'Reessayer',
                  action: function(){
                    $('#couverture').click();
                  },
                }
              },
            });
          }
        }
      });

      $('#addTag').click(function(e){
        e.preventDefault();
        var link = '<?php echo base_url();?>back/article/addType',
        libelle = $('#addLibelle').val();
        sending = {
          'addLibelle' : libelle
        };
        $.ajax({
          type: 'post',
          url: link,
          data: sending,
          success: function(){
            getType();
            $('#addLibelle').val('');
          }
        });
      })

    </script>
</body>
</html>
