<div class="container block">
<div class="columns">
        <!-- Aside nav drawer -->
        <div class="column">
            <p class="title">Actualités:</p>
            <div class="columns is-multiline box">
                <?php
                    $recent;
                    foreach($article as $valeur){
                        ?>
                            <div class="column is-4">
                                <div class="card" style="transition: all .1s ease;">
                                  <div class="card-image">
                                    <figure class="image is-4by3">
                                      <img src="<?php echo base_url('assets/img/article/couverture/'.$valeur->image);?>" alt="<?php echo $valeur->titre?>">
                                    </figure>
                                  </div>
                                  <div class="card-content">
                                    <div class="content">
                                      <a href="<?php
                                        echo site_url('cuf/actualite/'.$valeur->lien);
                                      ?>" class="actu-header"><?php echo $valeur->titre;?></a>
                                    </div>
                                    <div class="field">
                                            <div class="tags has-addons">
                                              <span class="tag is-dark">Section</span>
                                              <span class="tag is-primary"><?php echo $valeur->libelle;?></span>
                                            </div>
                                        </div>
                                        <div class="field">
                                            <div class="tags has-addons">
                                                <span class="tag is-dark"><span class="icon"><i class="fa fa-clock-o"></i></span></span>
                                              <span class="tag is-info">
                                                <?php
                                                    $date = explode('/',$valeur->publication);
                                                    switch ($date[1]) {
                                                        case 'January':
                                                            $date[1] = 'Janvier';
                                                            break;

                                                        case 'February':
                                                            $date[1] = 'Fevrier';
                                                            break;
                                                        
                                                        case 'March':
                                                            $date[1] = 'Mars';
                                                            break;

                                                        case 'April':
                                                            $date[1] = 'Avril';
                                                            break;

                                                        case 'Mai':
                                                            $date[1] = 'Mai';
                                                            break;

                                                        case 'June':
                                                            $date[1] = 'Juin';
                                                            break;

                                                        case 'July':
                                                            $date[1] = 'Juillet';
                                                            break;

                                                        case 'August':
                                                            $date[1] = 'Août';
                                                            break;
                                                        
                                                        case 'September':
                                                            $date[1] = 'Septembre';
                                                            break;

                                                        case 'October':
                                                            $date[1] = 'Octobre';
                                                            break;

                                                        case 'November':
                                                            $date[1] = 'Novembre';
                                                            break;

                                                        default:
                                                            $date[1] = 'Décembre';
                                                            break;
                                                    }

                                                    echo $date[0].' '.$date[1].' '.$date[2];
                                               ;?>
                                               </span>
                                            </div>
                                        </div>
                                        <div class="field">
                                            <div class="tags has-addons">
                                                <span class="tag is-dark"><span class="icon"><i class="fa fa-comments"></i></span></span>
                                              <span class="tag is-link">3</span>
                                            </div>
                                        </div>
                                  </div>
                                </div>
                            </div>
                        <?php
                    }
                ?>
            </div>
        </div>