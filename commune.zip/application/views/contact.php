<div class="container block">
<div class="columns">
        <!-- Aside nav drawer -->
        <div class="column">
            <p class="title">Contacter la commune:</p>
            <div class="columns box">
              <form class="column is-8 is-offset-2">
                    <div class="field">
                        <label class="label">Nom</label>
                        <div class="control">
                            <input class="input" type="text" placeholder="Text input">
                        </div>
                    </div>
                    <div class="field">
                        <label class="label">Prénoms</label>
                        <div class="control">
                            <input class="input" type="text" placeholder="Text input">
                        </div>
                    </div>
                    <div class="field">
                        <label class="label">Adresse mail</label>
                      <p class="control has-icons-left">
                        <input class="input" type="email" placeholder="Email">
                        <span class="icon is-small is-left">
                          <i class="fa fa-envelope"></i>
                        </span>
                      </p>
                    </div>
                    <div class="field">
                        <label class="label">Message</label>
                        <div class="control">
                            <textarea class="textarea" placeholder="Textarea"></textarea>
                        </div>
                    </div>
                    <div class="field is-grouped is-grouped-right">
                      <p class="control">
                        <a class="button is-info">
                          Envoyer
                        </a>
                      </p>
                    </div>
              </form>
            </div>
        </div>