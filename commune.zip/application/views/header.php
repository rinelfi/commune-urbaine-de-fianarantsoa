<?php
	$recent;
  $special = FALSE;
  if($this->uri->segment(2, 0) != '0'){
    if($this->Menu->menuGetInfo($this->uri->segment(2))[0]->type_contenu == 'custom'){
      $special = TRUE;
    }
  }
	foreach($menuParent as $valeur){
		if($this->uri->segment(2) == $valeur->reference){
			$recent = $valeur;
      if($this->uri->segment(1) != '' && $this->uri->segment(3) != '' && $this->Menu->menuGetInfo($this->uri->segment(2))[0]->type_contenu != 'custom'){
        $recent = $this->Menu->menuGetInfo($this->uri->segment(3));
        $recent = $recent[0];
      }
		}
	}
?>
<!DOCTYPE html>
<html class="has-navbar-fixed-top  nav-bar-spacing">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="<?php echo $recent->description;?>">
  <link rel="stylesheet" type="text/css" href="<?php echo css_url('bulma');?>">
  <link rel="stylesheet" type="text/css" href="<?php echo css_url('style');?>">
  <link rel="icon" type="image/png" href="<?php echo img_url('favicon', 'png')?>">
  <link rel="stylesheet" href="<?php echo css_url('font-awesome'); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo css_url('jquery-confirm.min');?>">
  <title><?php echo $recent->name;?></title>
</head>
<body>
  <div>
    <nav id="navbar" class="navbar is-fixed-top has-shadow is-spaced is-white" role="navigation" aria-label="dropdown navigation" style="transition: all .3s ease;">
      <div class="container">
        <div class="navbar-brand">
          <a href="<?php echo site_url();?>">
            <?php echo image('logo', 'png', 'Commune Urbaine de Fianarantsoa', array('width' => 140))?>
            </a>
          <div class="navbar-burger burger" data-target="menu">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>

        <div id="menu" class="navbar-menu">
          <div class="navbar-start">
            <?php
              foreach ($menuParent as $valeur) {
                if(count($this->Menu->menuGetChild($valeur->id)) > 0){        
                  ?>
                    <div class="navbar-item has-dropdown is-hoverable">
                      <a class="navbar-link" href="<?php echo site_url('cuf/'.$valeur->reference);?>" >
                        <?php echo $valeur->name;?>
                      </a>
                      <div class="navbar-dropdown is-boxed">
                        <?php
                          foreach($this->Menu->menuGetChild($valeur->id) as $lev2){
                            ?>
                            <a class="navbar-item" href="<?php echo site_url('cuf/'.$valeur->reference.'/'.$lev2->reference);?>">
                              <?php echo $lev2->name;?>
                            </a>
                          <?php
                          }
                        ?>
                      </div>
                     </div>
                  <?php
                }else{
                  if($valeur->reference == ''){
                    ?>
                      <a class="navbar-item " href="<?php echo site_url();?>">
                        <?php echo $valeur->name;?>
                      </a>
                    <?php
                  }else{
                  ?>
                    <a class="navbar-item" href="<?php echo site_url('cuf/'.$valeur->reference);?>">
                      <?php echo $valeur->name;?>
                    </a>
                  <?php
                  }
                }
              }
            ?>
          </div>
          <div class="navbar-end">
            <a class="navbar-item" id="search-icon">
              <span class="icon is-large">
                <i id="search-icon" class="fa fa-search"></i>
              </span>
            </a>
          </div>
        </div>
      </div>
    </nav>
  </div>
  <div>
  <section class="hero is-primary is-medium">
    <div class="hero-body banniere">
      <p id="animation1" class="container title">Commune Urbaine de Fianarantsoa</p>
      <p id="animation2" class="container subtitle">Soa fianatsa ro mahavokatsa</p>
    </div>
  </section>
</div>