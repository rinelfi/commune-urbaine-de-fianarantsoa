    <div class="column is-3">
        <nav class="panel has-background-white">
          <p class="panel-heading">
            Actualités
          </p>
          <div id="caroussel" class="columns is-mobile has-background-info">
            <a class="slide-control rounded" id="prev">
              <span class="icon has-background-primary has-text-white">
                <i class="fa fa-chevron-left"></i>
              </span>
            </a>
            <a class="slide-control rounded" id="next">
              <span class="icon has-background-primary has-text-white">
                <i class="fa fa-chevron-right"></i>
              </span>
            </a>
            <?php foreach($article as $actu){ ?>
              <div class="column is-8 is-offset-2 slideShow block">
                <div class="box">
                  <div class="card" style="transition: all .1s ease;">
                    <div class="card-image">
                      <figure class="image is-4by3">
                        <img src="<?php echo base_url('assets/img/article/couverture/'.$actu->image);?>">
                      </figure>
                    </div>
                    <div class="card-content">
                      <div class="content is-small">
                        <a href="<?php
                          $lien = str_replace(' ', '_', $actu->titre);
                          echo site_url('cuf/actualite/'.$lien);
                        ?>" class="actu-header titre-slide"><?php echo $actu->titre;?></a>
                      </div>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?>
        </div>
        </nav>
    </div>
</div>
</div>