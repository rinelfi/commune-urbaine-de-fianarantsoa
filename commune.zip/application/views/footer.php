<div class="hero-body has-background-primary">
  <div class="container">
    <!-- Begin MailChimp Signup Form -->
    <div class="columns is-vcentered">
      <div class="column is-one-third is-left">
        <p class="title is-4 has-text-white"><strong>RECEVEZ NOTRE NEWSLETTER</strong></p>
        <span class="subtitle is-4 has-text-white">Suivez l'actualité ainsi que les évenements qui se passe dans la commune</span>
      </div>
      <div class="column">
        <form>
          <div class="field is-grouped">
            <div class="control has-icons-left is-expanded">
              <input type="email" value="" class="input" placeholder="Adresse mail">
              <span class="icon is-small is-left">
                <i class="fa fa-envelope"></i>
              </span>
            </div>
            <div class="control">
              <input type="submit" value="Je m'abonne" class="button is-white">
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<footer class="footer">
    <a href="#" id="scroll-top">
      <span class="icon is-large has-text-white has-background-link">
        <i class="fa fa-arrow-up"></i>
      </span>
    </a>
  <div class="container">
    <div class="content has-text-centered">
      <p> © <strong>ITDC</strong> 2018 - <small>Le contenu de ce site est soumis à un droit d'auteur</small><br>
        <a class="">FAQ</a> | 
        <a class="">Conditions d'utilisation</a> | 
        <a class="">Politique de confidentialité</a>
      </p>
    </div>
    <div class="content has-text-centered">
      <p><strong>Suivez-nous sur les réseaux sociaux</strong>
        <div class="g-follow" data-annotation="bubble" data-height="20" data-href="//plus.google.com/u/0/116388270825621343283" data-rel="author"></div>
        <div class="fb-like" data-href="https://web.facebook.com/itdcmada/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="false" data-share="false"></div>
      </p>
    </div>
    <div class="content has-text-centered">
      <p><strong>Liens utiles</strong><br>
        <a>Liens 1</a><br>
        <a>Liens 1</a><br>
        <a>Liens 1</a><br>
        <a>Liens 1</a><br>
      </p>
    </div>
  </div>
</footer>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v3.2';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<script src="https://apis.google.com/js/platform.js" async defer>
  {lang: 'fr'}
</script>
<script type="text/javascript" src="<?php echo js_url('jquery')?>"></script>
    <script type="text/javascript" src="<?php echo js_url('jquery-confirm.min');?>"></script>
<script type="text/javascript" src="<?php echo js_url('main')?>"></script>