<?php
  defined('BASEPATH') OR exit('No direct script access allowed');
  class UriParse{
    public function __construct(){

    }

    public function strToUri($string){
      $pair = array(
        "A" => "a",
        "B" => "b",
        "C" => "c",
        "D" => "d",
        "E" => "e",
        "F" => "f",
        "G" => "g",
        "H" => "h",
        "I" => "i",
        "J" => "j",
        "K" => "k",
        "L" => "l",
        "M" => "m",
        "N" => "n",
        "O" => "o",
        "P" => "p",
        "Q" => "q",
        "R" => "r",
        "S" => "s",
        "T" => "t",
        "U" => "u",
        "V" => "v",
        "W" => "w",
        "X" => "x",
        "Y" => "y",
        "Z" => "z",
        "à" => "a",
        "ô" => "o",
        "ö" => "o",
        "ù" => "u",
        "û" => "u",
        "ü" => "u",
        "é" => "e",
        "è" => "e",
        "ê" => "e",
        "à" => "a",
        " " => "_",
        "-" => "_", 
        "“" => "_",
        "”" => "_",
        "," => "_",
      );
      $string = preg_replace("#((%){1}[A-F0-9]{1}[0-9]{1}){3}#", "_", $string);
      $string = strtr($string, $pair);
      return $string;
    }

  }
?>