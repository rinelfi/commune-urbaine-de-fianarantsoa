<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    if(!method_exists($this, 'css_url')){
        function css_url(string $name){
            return base_url()."assets/css/".$name.".css";
        }
    }

    if(!method_exists($this, 'js_url')){
        function js_url(String $name){
            return base_url().'assets/js/'.$name.'.js';
        }
    }

    if(!method_exists($this, 'img_url')){
        function img_url(String $name, String $extension = 'jpg'){
            return base_url().'assets/img/'.$name.'.'.$extension;
        }
    }

    if(!method_exists($this, 'image')){
        function image(String $name, String $extension = 'jpg', String $alt='', array $attributes = ['']){
            $image = '';
            if(array_key_exists('width', $attributes)){
                $image = '<img src="'.img_url($name, $extension).'" alt="'.$alt.'" width="'.$attributes['width'].'"';
            }else 
            if(array_key_exists('height', $attributes)){
                $image = '<img src="'.img_url($name, $extension).'" alt="'.$alt.'" height="'.$attributes['height'].'"'; 
            }else
            if(array_key_exists('width', $attributes) && array_key_exists('height', $attributes)){
                $image = '<img src="'.img_url($name, $extension).'" alt="'.$alt.'" width="'.$attributes['width'].'" height="'.$attributes['height'].'"'; 
            }else{
                $image = '<img src="'.img_url($name, $extension).'" alt="'.$alt.'"'; 
            }
            if(array_key_exists('class', $attributes)){
                $image.= 'class="'.$attributes['class'].'">';
            }else{
                $image.='>';
            }
            return $image;
        }
    }

    // if(!method_exists($this, 'cursor_url')){
    //     return base_url().'assets/img/'.$name.'.'.$extension;
    // }
?>