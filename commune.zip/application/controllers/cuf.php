<?php
	class Cuf extends CI_Controller{
		public $contenu = array('');
		public function __construct(){
			parent::__construct();
			$this->contenu['menuParent'] = $this->Menu->menuGetParent();
			$this->contenu['article'] = $this->Actualite->actuGetCard();
		}

		public function index(){
			$this->load->view('header', $this->contenu);
			$this->load->view('body', $this->contenu);
			$this->load->view('aside', $this->contenu);
			$this->load->view('footer', $this->contenu);
		}

		public function actualite($actualite = '', $tag = ''){
			$this->load->library('uriparse');
			$i = 0;
			foreach($this->contenu['article'] as $tmp){
				$this->contenu['article'][$i]->lien = $this->uriparse->strtouri($tmp->titre);
				$i++;
			}
			if($actualite != ''){
				$actualite = $this->uriparse->strtouri($actualite);
				$this->contenu['article'] = $this->Actualite->getArticle($actualite);
				$this->load->view('header', $this->contenu);
				$this->load->view('actu_affiche', $this->contenu);
				$this->load->view('aside', $this->contenu);
				$this->load->view('footer', $this->contenu);
			}else{
				$this->load->view('header', $this->contenu);
				$this->load->view('actualite', $this->contenu);
				$this->load->view('aside', $this->contenu);
				$this->load->view('footer', $this->contenu);
			}
		}

		public function evenement(){
			$this->load->view('header', $this->contenu);
			$this->load->view('evenement', $this->contenu);
			$this->load->view('aside', $this->contenu);
			$this->load->view('footer', $this->contenu);
		}

		public function decouvrir($decouverte = ''){
			if($decouverte == ''){
				redirect(site_url('cuf/decouvrir/vie_communale'),'refresh');
			}
			$this->load->view('header', $this->contenu);
			$this->load->view('body', $this->contenu);
			$this->load->view('aside', $this->contenu);
			$this->load->view('footer', $this->contenu);
		}

		public function site(){
			$this->load->view('header', $this->contenu);
			$this->load->view('lieu', $this->contenu);
			$this->load->view('aside', $this->contenu);
			$this->load->view('footer', $this->contenu);
		}

		public function contact(){
			$this->load->view('header', $this->contenu);
			$this->load->view('contact', $this->contenu);
			$this->load->view('aside', $this->contenu);
			$this->load->view('footer', $this->contenu);
		}

		public function photo(){
			$this->load->view('header', $this->contenu);
			$this->load->view('body', $this->contenu);
			$this->load->view('aside', $this->contenu);
			$this->load->view('footer', $this->contenu);
		}

		public function zavatra(){
			$this->load->view('header', $this->contenu);
			$this->load->view('body', $this->contenu);
			$this->load->view('aside', $this->contenu);
			$this->load->view('footer', $this->contenu);
		}
	}
?>