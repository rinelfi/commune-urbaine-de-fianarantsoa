<?php 
  class Sous_menu extends CI_Controller{
    public function __construct(){
      parent::__construct();
    }

    public function index(){
      $this->load->view('back/header');
      $this->load->view('back/sous-menu');
      $this->load->view('back/script');
    }

    public function getRecord($id = ''){
      if($id == ''){
        $result = $this->Menu->getParentAndChild();
        echo json_encode($result);
      }else{
        $result = $this->Menu->getParents($id);
        echo json_encode($result);
      }
    }

    public function getParent(){
      $result = $this->Menu->menuGetParent();
      echo json_encode($result);
    }

    public function addRecord(){
      $this->Menu->addMenu();
    }

    public function removeRecord($id){
      $this->Menu->removeMenu($id);
    }
    
    public function alterRecord($id){
      $this->Menu->alterMenu($id);
    }
  }
?>