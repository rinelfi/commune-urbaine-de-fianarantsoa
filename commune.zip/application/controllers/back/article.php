<?php 
  class Article extends CI_Controller{
    public function __construct(){
      parent::__construct();
    }

    public function index(){
      $this->load->view('back/header');
      $this->load->view('back/article');
      $this->load->view('back/script');
    }

    public function getRecord($id = ''){
      if($id == ''){
        $result = $this->Actualite->getAll();
        echo json_encode($result);
      }else{
        $result = $this->Actualite->getRecord($id);
        echo json_encode($result);
      }
    }

    public function getView($id){
      $result = $this->Actualite->getArticle($id);
      echo json_encode($result);
    }

    public function getType(){
      $result = $this->Actualite->getType();
      echo json_encode($result);
    }

    public function removeType($id){
      $this->Actualite->removeType($id);
    }

    public function addType(){
      $this->Actualite->addType();
    }

    public function addCover(){
      $config['upload_path'] = './assets/img/tmp';
      $config['max_size'] = 1024 * 7;
      $config['allowed_types'] = 'gif|png|jpg|jpeg';
      $config['overwrite'] = TRUE;
      $config['remove_spaces'] = FALSE;
      $this->load->library('upload', $config);
      $this->upload->do_upload('couverture');
    }

    public function changeCover(){
      $config['upload_path'] = './assets/img/tmp';
      $config['max_size'] = 1024 * 7;
      $config['allowed_types'] = 'gif|png|jpg|jpeg';
      $config['overwrite'] = TRUE;
      $config['remove_spaces'] = FALSE;
      $this->load->library('upload', $config);
      $this->upload->do_upload('couverture');
    }

    public function removeCover($file){
      $this->load->helper('file');
      $path = './assets/img/tmp/'.$file;
      $path = str_replace('%20', ' ', $path);
      echo $path;
      unlink($path);
    }

    public function addRecord(){
      $this->Actualite->addRecord();
      $tmpFile = './assets/img/tmp/'.$this->input->post('addImage');
      $fullPath = './assets/img/article/couverture/'.$this->input->post('addImage');
      copy($tmpFile, $fullPath);
      unlink($tmpFile);
    }

    public function removeRecord($id){
      $this->Actualite->removeRecord($id);
    }

    public function alterRecord($id){
      $this->Actualite->alterRecord($id);
      $oldImage = './assets/img/article/couverture/'.$this->input->post('oldImage');
      $tmpFile = './assets/img/tmp/'.$this->input->post('editImage');
      $fullPath = './assets/img/article/couverture/'.$this->input->post('editImage');
      if($oldImage != $fullPath){
        unlink($oldImage);
        copy($tmpFile, $fullPath);
        unlink($tmpFile);
      }
    }
  }
?>