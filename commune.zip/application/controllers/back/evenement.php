<?php 
  class Evenement extends CI_Controller{
    public function __construct(){
      parent::__construct();
    }

    public function index(){
      $this->load->view('back/header');
      $this->load->view('back/evenement');
      $this->load->view('back/script');
    }
  }
?>