<?php
  class Actualite extends CI_Model{
    private $table;
    private $type;

    public function __construct(){
      parent::__construct();
      $this->table = 'actualite';
      $this->type = 'type_actualite';
    }

    public function actuGetCard(){
      $query = $this->db->query('SELECT titre, image, DATE_FORMAT(publication, \'%d/%M/%Y\') as publication, contenu, libelle FROM '.$this->table.' INNER JOIN '.$this->type.' ON '.$this->type.'.id = type_actualite_id');
      return $query->result();
    }

    public function getArticle($reference){
      $query = $this->db->query('SELECT * FROM '.$this->table.' INNER JOIN administrateur ON editeur_id = administrateur.id WHERE titre LIKE "%'.$reference.'%" OR '.$this->table.'.id = "'.$reference.'"')->result();
      return $query;
    }

    public function getAll(){
      $query = $this->db->query('SELECT * ,'.$this->table.'.id as id1, DATE_FORMAT(publication, \'%d %M %Y\') as publication_complet FROM '.$this->type.' INNER JOIN '.$this->table.' ON '.$this->type.'.id = type_actualite_id INNER JOIN administrateur ON administrateur.id = editeur_id');
      return $query->result();
    }

    public function getRecord($id){
      $query = $this->db->query('SELECT * ,'.$this->table.'.id as id1, DATE_FORMAT(publication, \'%d %M %Y\') as publication_complet FROM '.$this->type.' INNER JOIN '.$this->table.' ON '.$this->type.'.id = type_actualite_id INNER JOIN administrateur ON administrateur.id = editeur_id WHERE '.$this->table.'.id = '.$id);
      return $query->result();
    }

    public function getType(){
      return $this->db->get($this->type)->result();
    }

    public function removeType($id){
      $this->db->delete($this->type, array('id' => $id));
    }

    public function addType(){
      $field = array(
        'libelle' => $this->input->post('addLibelle')
      );
      $this->db->insert($this->type, $field);
    }

    public function addRecord(){
      $this->db->set('type_actualite_id', $this->input->post('addType'));
      $this->db->set('editeur_id', 1);
      $this->db->set('titre', json_decode(json_encode(($this->input->post('addTitre')))));
      $this->db->set('image', $this->input->post('addImage'));
      $this->db->set('contenu', $this->input->post('addContenu'));
      $this->db->set('publication', 'NOW()', FALSE);
      $this->db->insert($this->table);
    }

    public function removeRecord($id){
      $this->db->delete('commentaire', array('actualite_id' => $id));
      $this->db->delete($this->table, array('id' => $id));
    }

    public function alterRecord($id){
      $field = array(
        'type_actualite_id' => $this->input->post('editType'),
        'editeur_id' => 1,
        'titre' => json_decode(json_encode(($this->input->post('editTitre')))),
        'image' => $this->input->post('editImage'),
        'contenu' => $this->input->post('editContenu'),
      );
      $this->db->where(array('id' => $id));
      $this->db->update($this->table, $field);
    }
  }
?>