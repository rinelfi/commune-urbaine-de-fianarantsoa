<?php
	class Menu extends CI_Model{
		private $table;
		public function __construct(){
			parent::__construct();
			$this->table = 'menu';
		}

		public function menuGetAll(){
			return $this->db->select('*')->from($this->table)->get()->result();
		}

		public function menuGetParent(){
			return $this->db->select('*')->from($this->table)->where('parent')->get()->result();
		}

		public function menuGetChild($id){
			return $this->db->select('*')->from($this->table)->where('parent', $id)->get()->result();
		}

		public function menuGetAllChild(){
			return $this->db->query('SELECT * FROM '.$this->table.'  WHERE parent IS NOT NULL')->result();
		}

		public function getParents($id){
			return $this->db->query('SELECT * FROM '.$this->table.'  WHERE id = '.$id)->result();
		}

    public function getParentAndChild(){
      return $this->db->query('SELECT m1.id as id1, m1.name as name1, m1.reference as reference1, m2.reference  as reference2, m2.name as name2, m1.type_contenu as type1 FROM menu as m1 inner join menu as m2 on m1.parent = m2.id ORDER BY m1.parent ASC')->result();
    }

		public function menuGetInfo($reference){
			if($reference == 'cuf'){
				$reference = '';
			}
			return $this->db->select('*')->from($this->table)->where('reference', $reference)->get()->result();
		}

    public function alterMenu($id){
      $field = array(
        'name' => $this->input->post('editNom'),
        'reference' => $this->input->post('editReference'),
        'type_contenu' => $this->input->post('editType'),
        'parent' => $this->input->post('editParent'),
        'contenu' => $this->input->post('editContenu'),
        'description' => $this->input->post('editDescription')
      );
      $this->db->where('id', $id);
      $this->db->update($this->table, $field);
    }

		public function addMenu(){
      $field = array(
        'name' => $this->input->post('addNom'),
        'reference' => $this->input->post('addReference'),
        'type_contenu' => $this->input->post('addType'),
        'parent' => $this->input->post('addParent'),
        'contenu' => $this->input->post('addContenu'),
        'description' => $this->input->post('addDescription')
      );
      $this->db->insert($this->table, $field);
		}

    public function removeMenu($id){
      $this->db->delete($this->table, array('id' => $id));
    }
	}
?>